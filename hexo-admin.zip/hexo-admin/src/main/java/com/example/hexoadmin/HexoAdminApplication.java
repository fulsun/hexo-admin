package com.example.hexoadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexoAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexoAdminApplication.class, args);
	}

}
