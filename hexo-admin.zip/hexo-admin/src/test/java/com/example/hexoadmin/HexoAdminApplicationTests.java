package com.example.hexoadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexoAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
